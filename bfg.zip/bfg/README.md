### Скрипт бота [@BFGcopybot](https://t.me/BFGcopybot)

## Инструкция по установке:
- Склонируйте репозиторий:
```bash
git clone https://github.com/Ijidishurka/bfg
```

- Перейдите в папку с ботом:
```bash
cd bfg
```

- Установите зависимости:
```bash
pip install -r req*
```

- Запустить бота
```bash
python -m main
```

![скришнот запуска](https://te.legra.ph/file/37d6f3b654c5a4bca9712.jpg)


## Скриншоты бота:
![скришнот 1](https://te.legra.ph/file/385ffe85ba0296df9e3c0.jpg)
![скришнот 2](https://te.legra.ph/file/55629cbac5fe97ebb3125.jpg)
![скришнот 3](https://te.legra.ph/file/177aed4921e23b90507a3.jpg)
![скришнот 4](https://te.legra.ph/file/7d1b946fec2dcb89a6556.jpg)

Мой канал [@UBscripts](https://t.me/UBscripts)
